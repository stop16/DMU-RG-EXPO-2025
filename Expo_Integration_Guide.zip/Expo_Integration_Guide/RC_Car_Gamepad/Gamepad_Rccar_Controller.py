import serial
import time
import pygame

PORT = 'COM30'
BAUDRATE = 9600

def connect_serial(port, baudrate):
    """
    시리얼 포트에 연결을 시도하고, 성공하면 객체를 반환합니다.
    실패하면 프로그램을 종료합니다.
    """
    try:
        ser = serial.Serial(
            port=port,
            baudrate=baudrate,
            timeout=0.1,
            write_timeout=0.2
        )
        if not ser.isOpen():
            ser.open()
        print(f"✅ 시리얼 포트 {port} 연결됨.")
        return ser
    except serial.SerialException as e:
        print(f"❌ 오류: 포트 {port} 열 수 없음. 다른 장치가 점유 중일 수 있습니다.")
        print(f"에러 메시지: {e}")
        exit()

# --- 메인 프로그램 시작 ---
# 시리얼 포트 초기 연결
try:
    serialHandle = serial.Serial(
        port=PORT,
        baudrate=BAUDRATE,
        timeout=0.1,
        write_timeout=0.2
    )
    if not serialHandle.isOpen():
        serialHandle.open()
except serial.SerialException as e:
    print(f"오류: 시리얼 포트('{PORT}')를 열 수 없습니다.")
    print(f"포트 번호가 맞는지, 다른 프로그램이 사용 중이지 않은지 확인해주세요.")
    print(f"에러 메시지: {e}")
    exit()

# --- Pygame 및 컨트롤러 초기화 ---
pygame.init()
pygame.joystick.init()

joystick_count = pygame.joystick.get_count()
if joystick_count == 0:
    print("❌ 컨트롤러가 감지되지 않았습니다. 프로그램을 종료합니다.")
    exit()

# 첫 번째 컨트롤러 사용
joystick = pygame.joystick.Joystick(0)
joystick.init()
print(f"✅ 컨트롤러 '{joystick.get_name()}' 감지됨.")
print(f"조이스틱 축 개수: {joystick.get_numaxes()}")
print(f"조이스틱 버튼 개수: {joystick.get_numbuttons()}")

last_data_str = ""

try:
    print("RC카 조종을 시작합니다. (컨트롤러 조이스틱 사용)")
    print("왼쪽 스틱 Y축: 전진/후진 (스로틀/브레이크)")
    print("오른쪽 스틱 X축: 좌/우 조향")

    # --- 속도 조절 변수  ---
    MAX_THROTTLE_SPEED = 130 # 전진 최대 속도 (0-255)
    MAX_BRAKE_SPEED = 110    # 후진/브레이크 최대 속도 (0-255)
    # ---------------------------------

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                raise KeyboardInterrupt

        # --- 컨트롤러 입력 값 읽기 (Gamesir G7-SE 예상 축 번호) ---
        left_y_axis = joystick.get_axis(1) 
        right_x_axis = joystick.get_axis(2) 

        # 스로틀 및 브레이크 계산
        throttle = 0
        brake = 0
        deadzone = 0.1 # 조이스틱 데드존 설정

        if left_y_axis < -deadzone: # 위로 밀었을 때 (전진)
            throttle = int(abs(left_y_axis) * MAX_THROTTLE_SPEED) 
        elif left_y_axis > deadzone: # 아래로 밀었을 때 (후진/브레이크)
            brake = int(abs(left_y_axis) * MAX_BRAKE_SPEED) 

        # 조향 계산 (0: 좌, 127: 중앙, 255: 우)
        steering = 127

        if right_x_axis < -deadzone: # 왼쪽으로 밀었을 때 (좌회전)
            steering = int(127 - (abs(right_x_axis) * 47)) # right_x_axis가 -1.0일 때 90이 되고, 0.0일 때 127이 되도록 매핑 
            # 127 + (-1.0 * (127 - 80)) = 127 - 47 = 80
        elif right_x_axis > deadzone: # 오른쪽으로 밀었을 때 (우회전)
            steering = int(127 + (abs(right_x_axis) * 48)) #  right_x_axis가 1.0일 때 165가 되고, 0.0일 때 127이 되도록 매핑
            # 127 + (1.0 * (175 - 127)) = 127 + 48 = 175
        
        # 값을 90-165 범위로 클램핑
        steering = max(90, min(165, steering))

        # 값을 0-255 범위로 클램핑 (스로틀, 브레이크)
        throttle = max(0, min(255, throttle))
        brake = max(0, min(255, brake))


        current_data_str = f"0,0,{throttle},{brake},{steering},0,0\n"

        if current_data_str != last_data_str:
            serialHandle.write(current_data_str.encode())
            print(f"전송됨: {current_data_str.strip()}")
            last_data_str = current_data_str
        
        time.sleep(0.02)

except serial.SerialTimeoutException:
    print("write timeout 발생! 시리얼 포트 재연결 중...")
    try:
        serialHandle.close()
    except:
        pass
    serialHandle = connect_serial(PORT, BAUDRATE)

except KeyboardInterrupt:
    print("\n프로그램을 종료합니다.")
    if serialHandle and serialHandle.isOpen():
        serialHandle.close()
        print("시리얼 포트를 닫았습니다.")
    pygame.quit()
except Exception as e:
    print(f"\n예상치 못한 오류 발생: {e}")
    if serialHandle and serialHandle.isOpen():
        serialHandle.close()
    pygame.quit()